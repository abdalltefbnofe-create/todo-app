package com.example.todo;

import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Toast;

import java.util.Random;

/** أدوات صغيرة للاحتفال بالإنجاز: نبضة، اهتزاز خفيف، قصاصات، ورسالة تشجيع. */
final class Celebrate {

    private static final Random RANDOM = new Random();

    private Celebrate() {}

    /** تكبير سريع ثم عودة للحجم الطبيعي. */
    static void bounce(final View v) {
        v.animate().cancel();
        v.animate()
                .scaleX(1.4f)
                .scaleY(1.4f)
                .setDuration(120)
                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start())
                .start();
    }

    static void haptic(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
    }

    /** قصاصات تنطلق من مركز العنصر المضغوط. */
    static void burstFrom(ConfettiView confetti, View anchor, int count) {
        int[] a = new int[2];
        int[] b = new int[2];
        anchor.getLocationInWindow(a);
        confetti.getLocationInWindow(b);
        confetti.burst(a[0] - b[0] + anchor.getWidth() / 2f,
                a[1] - b[1] + anchor.getHeight() / 2f, count);
    }

    /** احتفال كبير عند إنجاز كل المهام. */
    static void bigBurst(ConfettiView confetti) {
        float w = confetti.getWidth();
        float h = confetti.getHeight();
        confetti.burst(w * 0.2f, h * 0.45f, 70);
        confetti.burst(w * 0.8f, h * 0.45f, 70);
        confetti.burst(w * 0.5f, h * 0.35f, 90);
    }

    static void cheer(Context context) {
        String[] cheers = context.getResources().getStringArray(R.array.cheers);
        Toast.makeText(context, cheers[RANDOM.nextInt(cheers.length)], Toast.LENGTH_SHORT).show();
    }
}
