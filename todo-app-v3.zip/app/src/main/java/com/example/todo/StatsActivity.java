package com.example.todo;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** شاشة الإنجازات: السلسلة، أرقام سريعة، ومخطط آخر 7 أيام. */
public class StatsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        int[] days = Stats.lastDays(this, 7);
        int streak = Stats.streak(this);
        int week = 0;
        for (int d : days) week += d;

        ((TextView) findViewById(R.id.streak_value))
                .setText(getString(R.string.streak_fmt, streak));
        ((TextView) findViewById(R.id.streak_label))
                .setText(streak == 0 ? R.string.stats_empty : R.string.streak_label);
        ((TextView) findViewById(R.id.stat_today)).setText(String.valueOf(days[6]));
        ((TextView) findViewById(R.id.stat_week)).setText(String.valueOf(week));
        ((TextView) findViewById(R.id.stat_total)).setText(String.valueOf(Stats.total(this)));
        ((TextView) findViewById(R.id.stat_best)).setText(String.valueOf(Stats.bestStreak(this)));

        buildChart(days);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildChart(int[] days) {
        LinearLayout chart = findViewById(R.id.chart_container);
        chart.removeAllViews();

        int max = 1;
        for (int d : days) max = Math.max(max, d);

        SimpleDateFormat fmt = new SimpleDateFormat("EEE", Locale.forLanguageTag("ar"));
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -(days.length - 1));

        for (int i = 0; i < days.length; i++) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            col.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

            TextView count = new TextView(this);
            count.setText(days[i] > 0 ? String.valueOf(days[i]) : "");
            count.setTextSize(12);
            count.setTextColor(getColor(R.color.text_secondary));
            count.setGravity(Gravity.CENTER);

            int barHeight = days[i] == 0
                    ? dp(4)
                    : Math.max(dp(8), Math.round(dp(100) * days[i] / (float) max));
            View bar = new View(this);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(18), barHeight);
            bp.topMargin = dp(4);
            bp.bottomMargin = dp(6);
            bar.setLayoutParams(bp);
            GradientDrawable shape = new GradientDrawable();
            shape.setCornerRadius(dp(6));
            if (i == days.length - 1) {
                shape.setColor(getColor(R.color.success));
            } else if (days[i] == 0) {
                shape.setColor(getColor(R.color.card_border));
            } else {
                shape.setColor(getColor(R.color.primary));
            }
            bar.setBackground(shape);

            TextView label = new TextView(this);
            label.setText(fmt.format(cal.getTime()));
            label.setTextSize(11);
            label.setTextColor(getColor(R.color.text_secondary));
            label.setGravity(Gravity.CENTER);
            cal.add(Calendar.DAY_OF_YEAR, 1);

            col.addView(count);
            col.addView(bar);
            col.addView(label);
            chart.addView(col);
        }
    }
}
