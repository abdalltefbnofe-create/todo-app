package com.example.todo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.List;

/** يستقبل إشارة المنبّه ويُظهر إشعار التذكير، ثم يحرّك موعد المهمة المتكررة. */
public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        long id = intent.getLongExtra(ReminderScheduler.EXTRA_TASK_ID, -1);
        if (id == -1) return;

        TaskStore store = new TaskStore(context);
        List<Task> all = store.load(); // التحميل يعيد فتح المهام المتكررة عند حلول موعدها
        Task task = TaskStore.find(all, id);
        if (task == null) return;

        if (!task.done) {
            ReminderScheduler.showNotification(context, task);
        }

        if (task.repeat != Task.REPEAT_NONE && task.startTime > 0) {
            long now = System.currentTimeMillis();
            int step = TaskStore.repeatStep(task.repeat);
            while (task.startTime <= now) {
                task.startTime = TaskStore.addDays(task.startTime, step);
            }
            store.save(all);
            ReminderScheduler.schedule(context, task);
        }
    }
}
