package com.example.todo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;

/** شاشة تفاصيل المهمة: العنوان، الوقت، التصنيف، الأولوية، التكرار، والخطوات الصغيرة. */
public class TaskDetailActivity extends Activity {

    public static final String EXTRA_TASK_ID = "task_id";

    private TaskStore store;
    private Task task;
    private boolean deleted = false;

    private EditText titleInput;
    private EditText stepInput;
    private TextView timeText;
    private TextView stepsProgress;
    private TextView stepsHint;
    private LinearLayout stepsContainer;
    private Button pickTimeButton;
    private Button clearTimeButton;
    private Button doneButton;
    private ConfettiView confetti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        store = new TaskStore(this);
        long id = getIntent().getLongExtra(EXTRA_TASK_ID, -1);
        task = TaskStore.find(store.load(), id);
        if (task == null) {
            finish();
            return;
        }

        titleInput = findViewById(R.id.title_input);
        stepInput = findViewById(R.id.step_input);
        timeText = findViewById(R.id.time_text);
        stepsProgress = findViewById(R.id.steps_progress);
        stepsHint = findViewById(R.id.steps_hint);
        stepsContainer = findViewById(R.id.steps_container);
        pickTimeButton = findViewById(R.id.btn_pick_time);
        clearTimeButton = findViewById(R.id.btn_clear_time);
        doneButton = findViewById(R.id.btn_done);
        confetti = findViewById(R.id.confetti);

        titleInput.setText(task.title);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        findViewById(R.id.btn_delete_task).setOnClickListener(v -> confirmDelete());
        pickTimeButton.setOnClickListener(v -> pickTime());
        clearTimeButton.setOnClickListener(v -> {
            task.startTime = 0;
            persist();
            render();
        });
        findViewById(R.id.btn_add_step).setOnClickListener(v -> addStep());
        stepInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                addStep();
                return true;
            }
            return false;
        });
        doneButton.setOnClickListener(v -> toggleDone(v));

        setupOptions();
        render();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!deleted && task != null) persist();
    }

    // ---------- التصنيف والأولوية والتكرار ----------
    private void setupOptions() {
        Spinner categorySpinner = findViewById(R.id.category_spinner);
        int last = categorySpinner.getAdapter().getCount() - 1;
        categorySpinner.setSelection(Math.max(0, Math.min(task.category, last)));
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (pos != task.category) {
                    task.category = pos;
                    persist();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        RadioGroup rgPriority = findViewById(R.id.rg_priority);
        rgPriority.check(task.priority == 2 ? R.id.rb_p2
                : (task.priority == 1 ? R.id.rb_p1 : R.id.rb_p0));
        rgPriority.setOnCheckedChangeListener((group, checkedId) -> {
            int p = checkedId == R.id.rb_p2 ? 2 : (checkedId == R.id.rb_p1 ? 1 : 0);
            if (p != task.priority) {
                task.priority = p;
                persist();
            }
        });

        RadioGroup rgRepeat = findViewById(R.id.rg_repeat);
        rgRepeat.check(task.repeat == Task.REPEAT_WEEKLY ? R.id.rb_r2
                : (task.repeat == Task.REPEAT_DAILY ? R.id.rb_r1 : R.id.rb_r0));
        rgRepeat.setOnCheckedChangeListener((group, checkedId) -> {
            int r = checkedId == R.id.rb_r2 ? Task.REPEAT_WEEKLY
                    : (checkedId == R.id.rb_r1 ? Task.REPEAT_DAILY : Task.REPEAT_NONE);
            if (r != task.repeat) {
                task.repeat = r;
                persist();
            }
        });
    }

    // ---------- الحفظ ----------
    private void persist() {
        String newTitle = titleInput.getText().toString().trim();
        if (!newTitle.isEmpty()) task.title = newTitle;

        List<Task> all = store.load();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id == task.id) {
                all.set(i, task);
                store.save(all);
                ReminderScheduler.schedule(this, task);
                return;
            }
        }
    }

    // ---------- العرض ----------
    private void render() {
        if (task.startTime > 0) {
            timeText.setText("⏰ " + Task.formatTime(task.startTime));
            pickTimeButton.setText(R.string.change_time);
            clearTimeButton.setVisibility(View.VISIBLE);
        } else {
            timeText.setText(R.string.time_none);
            pickTimeButton.setText(R.string.pick_time);
            clearTimeButton.setVisibility(View.GONE);
        }

        stepsContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (final Task.SubTask sub : task.subtasks) {
            final View row = inflater.inflate(R.layout.item_subtask, stepsContainer, false);
            bindStepRow(row, sub);
            row.findViewById(R.id.sub_check).setOnClickListener(v -> toggleStep(sub, row, v));
            row.findViewById(R.id.sub_delete).setOnClickListener(v -> {
                task.subtasks.remove(sub);
                persist();
                render();
            });
            stepsContainer.addView(row);
        }
        stepsHint.setVisibility(task.subtasks.isEmpty() ? View.VISIBLE : View.GONE);
        updateStepsProgress();

        doneButton.setText(task.done ? R.string.btn_undo : R.string.btn_done);
    }

    private void bindStepRow(View row, Task.SubTask sub) {
        ImageView check = row.findViewById(R.id.sub_check);
        TextView text = row.findViewById(R.id.sub_text);
        text.setText(sub.text);
        check.setImageResource(sub.done ? R.drawable.ic_check_on : R.drawable.ic_check_off);
        if (sub.done) {
            text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            text.setAlpha(0.55f);
        } else {
            text.setPaintFlags(text.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            text.setAlpha(1f);
        }
    }

    private void updateStepsProgress() {
        if (task.subtasks.isEmpty()) {
            stepsProgress.setText("");
        } else {
            stepsProgress.setText(getString(R.string.steps_progress,
                    task.doneSubtasks(), task.subtasks.size()));
        }
    }

    // ---------- الخطوات ----------
    private void addStep() {
        String text = stepInput.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, R.string.empty_warning, Toast.LENGTH_SHORT).show();
            return;
        }
        task.subtasks.add(new Task.SubTask(text, false));
        stepInput.setText("");
        persist();
        render();
    }

    private void toggleStep(Task.SubTask sub, View row, View checkView) {
        sub.done = !sub.done;
        persist();
        bindStepRow(row, sub);
        updateStepsProgress();

        if (sub.done) {
            Celebrate.haptic(checkView);
            Celebrate.bounce(checkView);
            if (task.allSubtasksDone()) {
                Celebrate.burstFrom(confetti, checkView, 80);
                Toast.makeText(this, R.string.steps_all_done, Toast.LENGTH_LONG).show();
            }
        }
    }

    // ---------- إنجاز المهمة ----------
    private void toggleDone(View button) {
        store.applyDone(task, !task.done);
        persist();
        render();
        if (task.done) {
            Celebrate.haptic(button);
            Celebrate.burstFrom(confetti, button, 90);
            Celebrate.cheer(this);
        }
    }

    // ---------- وقت البدء والتذكير ----------
    private void pickTime() {
        final Calendar c = Calendar.getInstance();
        if (task.startTime > 0) c.setTimeInMillis(task.startTime);

        DatePickerDialog dateDialog = new DatePickerDialog(this, (view, year, month, day) -> {
            TimePickerDialog timeDialog = new TimePickerDialog(this, (tp, hour, minute) -> {
                Calendar sel = Calendar.getInstance();
                sel.set(year, month, day, hour, minute, 0);
                sel.set(Calendar.MILLISECOND, 0);
                if (sel.getTimeInMillis() <= System.currentTimeMillis()) {
                    Toast.makeText(this, R.string.past_time_warning, Toast.LENGTH_SHORT).show();
                    return;
                }
                task.startTime = sel.getTimeInMillis();
                persist();
                render();
                Toast.makeText(this, R.string.reminder_set, Toast.LENGTH_SHORT).show();
                afterTimeSet();
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), DateFormat.is24HourFormat(this));
            timeDialog.show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dateDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        dateDialog.show();
    }

    /** يطلب إذن الإشعارات (أندرويد 13+) أو ينبّه لتفعيل المنبّهات الدقيقة (أندرويد 12+). */
    private void afterTimeSet() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && !ReminderScheduler.canScheduleExact(this)) {
            SharedPreferences sp = getSharedPreferences("todo_prefs", MODE_PRIVATE);
            if (!sp.getBoolean("exact_hint_shown", false)) {
                sp.edit().putBoolean("exact_hint_shown", true).apply();
                new AlertDialog.Builder(this)
                        .setTitle(R.string.exact_title)
                        .setMessage(R.string.exact_msg)
                        .setPositiveButton(R.string.open_settings, (d, w) -> {
                            try {
                                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                        Uri.parse("package:" + getPackageName())));
                            } catch (Exception ignored) {
                                // بعض الأجهزة لا تدعم هذه الشاشة
                            }
                        })
                        .setNegativeButton(R.string.later, null)
                        .show();
            }
        }
    }

    // ---------- الحذف ----------
    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirm_delete_title)
                .setMessage(R.string.confirm_delete_msg)
                .setPositiveButton(R.string.yes_delete, (d, w) -> {
                    List<Task> all = store.load();
                    Task cur = TaskStore.find(all, task.id);
                    if (cur != null) all.remove(cur);
                    ReminderScheduler.cancel(this, task.id);
                    store.save(all);
                    deleted = true;
                    finish();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
