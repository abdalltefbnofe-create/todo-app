package com.example.todo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** مهمة واحدة، وقد تحتوي على خطوات صغيرة ووقت بدء وأولوية وتصنيف وتكرار. */
public class Task {

    public static final int REPEAT_NONE = 0;
    public static final int REPEAT_DAILY = 1;
    public static final int REPEAT_WEEKLY = 2;

    public long id;
    public String title;
    public boolean done;
    /** وقت البدء بالمللي ثانية، والقيمة 0 تعني عدم وجود وقت. */
    public long startTime;
    public long completedAt;
    /** 0 عادي، 1 مهم، 2 عاجل. */
    public int priority;
    /** رقم التصنيف في قائمة التصنيفات، و0 يعني بدون تصنيف. */
    public int category;
    /** 0 لا يتكرر، 1 يومياً، 2 أسبوعياً. */
    public int repeat;
    public final List<SubTask> subtasks = new ArrayList<>();

    public static class SubTask {
        public String text;
        public boolean done;

        public SubTask(String text, boolean done) {
            this.text = text;
            this.done = done;
        }
    }

    public Task(long id, String title) {
        this.id = id;
        this.title = title;
    }

    public int doneSubtasks() {
        int n = 0;
        for (SubTask s : subtasks) {
            if (s.done) n++;
        }
        return n;
    }

    public boolean allSubtasksDone() {
        return !subtasks.isEmpty() && doneSubtasks() == subtasks.size();
    }

    public static String formatTime(long millis) {
        return new SimpleDateFormat("EEE d MMM، h:mm a", Locale.forLanguageTag("ar"))
                .format(new Date(millis));
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("done", done);
        o.put("startTime", startTime);
        o.put("completedAt", completedAt);
        o.put("priority", priority);
        o.put("category", category);
        o.put("repeat", repeat);
        JSONArray subs = new JSONArray();
        for (SubTask s : subtasks) {
            JSONObject so = new JSONObject();
            so.put("text", s.text);
            so.put("done", s.done);
            subs.put(so);
        }
        o.put("subtasks", subs);
        return o;
    }

    /** يقرأ كل الصيغ القديمة والجديدة، والحقول الناقصة تأخذ قيماً افتراضية. */
    public static Task fromJson(JSONObject o, long fallbackId) throws JSONException {
        String title = o.optString("title", o.optString("text", ""));
        Task t = new Task(o.optLong("id", fallbackId), title);
        t.done = o.optBoolean("done", false);
        t.startTime = o.optLong("startTime", 0);
        t.completedAt = o.optLong("completedAt", 0);
        t.priority = Math.max(0, Math.min(2, o.optInt("priority", 0)));
        t.category = Math.max(0, o.optInt("category", 0));
        t.repeat = Math.max(0, Math.min(2, o.optInt("repeat", 0)));
        JSONArray subs = o.optJSONArray("subtasks");
        if (subs != null) {
            for (int i = 0; i < subs.length(); i++) {
                JSONObject so = subs.getJSONObject(i);
                t.subtasks.add(new SubTask(so.optString("text", ""), so.optBoolean("done", false)));
            }
        }
        return t;
    }
}
