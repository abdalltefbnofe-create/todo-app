package com.example.todo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.List;

/** ويدجت الشاشة الرئيسية: يعرض المهام المتبقية، والضغط على مهمة ينجزها. */
public class TodoWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_TOGGLE = "com.example.todo.WIDGET_TOGGLE";
    public static final String EXTRA_TASK_ID = "task_id";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            manager.updateAppWidget(id, buildViews(context, id));
        }
        manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_list);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            long id = intent.getLongExtra(EXTRA_TASK_ID, -1);
            if (id != -1) {
                TaskStore store = new TaskStore(context);
                List<Task> all = store.load();
                Task t = TaskStore.find(all, id);
                if (t != null) {
                    store.applyDone(t, true);
                    store.save(all); // يحدّث الويدجت تلقائياً
                    ReminderScheduler.schedule(context, t);
                }
            }
        }
    }

    public static void refreshAll(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(context, TodoWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        for (int id : ids) {
            mgr.updateAppWidget(id, buildViews(context, id));
        }
        mgr.notifyAppWidgetViewDataChanged(ids, R.id.widget_list);
    }

    private static RemoteViews buildViews(Context context, int widgetId) {
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget_todo);

        Intent svc = new Intent(context, TodoWidgetService.class);
        svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        svc.setData(Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME)));
        rv.setRemoteAdapter(R.id.widget_list, svc);
        rv.setEmptyView(R.id.widget_list, R.id.widget_empty);

        int pending = 0;
        for (Task t : new TaskStore(context).load()) {
            if (!t.done) pending++;
        }
        rv.setTextViewText(R.id.widget_count,
                pending == 0 ? "" : context.getString(R.string.widget_count, pending));

        // الضغط على مهمة داخل القائمة
        Intent toggle = new Intent(context, TodoWidgetProvider.class);
        toggle.setAction(ACTION_TOGGLE);
        int mutable = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
        rv.setPendingIntentTemplate(R.id.widget_list,
                PendingIntent.getBroadcast(context, 0, toggle,
                        PendingIntent.FLAG_UPDATE_CURRENT | mutable));

        // الضغط على العنوان يفتح التطبيق
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        rv.setOnClickPendingIntent(R.id.widget_header,
                PendingIntent.getActivity(context, 1, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        // زر + يفتح التطبيق ويجهّز خانة الكتابة
        Intent add = new Intent(context, MainActivity.class);
        add.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        add.putExtra(MainActivity.EXTRA_FOCUS_INPUT, true);
        rv.setOnClickPendingIntent(R.id.widget_add,
                PendingIntent.getActivity(context, 2, add,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        return rv;
    }
}
