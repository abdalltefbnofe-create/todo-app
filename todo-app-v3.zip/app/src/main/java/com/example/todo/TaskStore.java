package com.example.todo;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

/** التخزين المحلي للمهام (SharedPreferences بصيغة JSON) ومنطق الإنجاز والتكرار والنسخ الاحتياطي. */
public class TaskStore {

    private static final String PREFS_NAME = "todo_prefs";
    private static final String KEY_TASKS = "tasks";

    private final Context context;

    public TaskStore(Context context) {
        this.context = context.getApplicationContext();
    }

    private SharedPreferences prefs() {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ---------- أدوات الوقت ----------
    public static long startOfDay(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static long addDays(long millis, int days) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTimeInMillis();
    }

    public static int repeatStep(int repeat) {
        return repeat == Task.REPEAT_WEEKLY ? 7 : 1;
    }

    // ---------- القراءة والحفظ ----------
    public List<Task> load() {
        List<Task> list = new ArrayList<>();
        boolean migrated = false;
        try {
            JSONArray array = new JSONArray(prefs().getString(KEY_TASKS, "[]"));
            long base = System.currentTimeMillis();
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                if (!o.has("id")) migrated = true; // مهمة من الإصدار القديم
                Task t = Task.fromJson(o, base - i);
                if (t.title != null && !t.title.isEmpty()) list.add(t);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        List<Task> reset = rollover(list);
        if (migrated || !reset.isEmpty()) save(list);
        for (Task t : reset) ReminderScheduler.schedule(context, t);
        return list;
    }

    public void save(List<Task> tasks) {
        JSONArray array = new JSONArray();
        try {
            for (Task t : tasks) array.put(t.toJson());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        prefs().edit().putString(KEY_TASKS, array.toString()).apply();
        TodoWidgetProvider.refreshAll(context);
    }

    public static Task find(List<Task> tasks, long id) {
        for (Task t : tasks) {
            if (t.id == id) return t;
        }
        return null;
    }

    /** ترتيب مستقر: الأعلى أولوية أولاً مع بقاء الترتيب الأصلي بين المتساويين. */
    public static void sortPending(List<Task> list) {
        Collections.sort(list, (a, b) -> Integer.compare(b.priority, a.priority));
    }

    // ---------- الإنجاز والتكرار ----------
    /** يغيّر حالة الإنجاز ويسجّل الإحصائيات ويحرّك موعد المهمة المتكررة. لا يحفظ المهام. */
    public void applyDone(Task t, boolean done) {
        long now = System.currentTimeMillis();
        if (done && !t.done) {
            t.done = true;
            t.completedAt = now;
            Stats.record(context, now);
            if (t.repeat != Task.REPEAT_NONE && t.startTime > 0) {
                int step = repeatStep(t.repeat);
                do {
                    t.startTime = addDays(t.startTime, step);
                } while (t.startTime <= now);
            }
        } else if (!done && t.done) {
            Stats.undo(context, t.completedAt);
            t.done = false;
            t.completedAt = 0;
        }
    }

    /** المهام المتكررة المنجزة تعود غير منجزة (وخطواتها كذلك) عند حلول اليوم أو الأسبوع التالي. */
    private List<Task> rollover(List<Task> list) {
        List<Task> reset = new ArrayList<>();
        long now = System.currentTimeMillis();
        long todayStart = startOfDay(now);
        for (Task t : list) {
            if (!t.done || t.repeat == Task.REPEAT_NONE) continue;
            long doneDay = startOfDay(t.completedAt > 0 ? t.completedAt : now);
            boolean due = t.repeat == Task.REPEAT_DAILY
                    ? doneDay < todayStart
                    : now >= addDays(doneDay, 7);
            if (!due) continue;

            t.done = false;
            t.completedAt = 0;
            for (Task.SubTask s : t.subtasks) s.done = false;
            if (t.startTime > 0) {
                int step = repeatStep(t.repeat);
                while (t.startTime <= now) t.startTime = addDays(t.startTime, step);
            }
            reset.add(t);
        }
        return reset;
    }

    // ---------- النسخ الاحتياطي ----------
    public String exportJson() {
        JSONObject root = new JSONObject();
        try {
            root.put("app", "mahami");
            root.put("version", 3);
            JSONArray arr = new JSONArray();
            for (Task t : load()) arr.put(t.toJson());
            root.put("tasks", arr);
            root.put("history", Stats.load(context));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return root.toString();
    }

    /** يستبدل المهام الحالية بمحتوى النسخة الاحتياطية. يعيد false إن كان الملف غير صالح. */
    public boolean importJson(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONArray arr = root.getJSONArray("tasks");
            List<Task> list = new ArrayList<>();
            long base = System.currentTimeMillis();
            for (int i = 0; i < arr.length(); i++) {
                Task t = Task.fromJson(arr.getJSONObject(i), base - i);
                if (t.title != null && !t.title.isEmpty()) list.add(t);
            }
            for (Task old : load()) ReminderScheduler.cancel(context, old.id);
            save(list);
            JSONObject history = root.optJSONObject("history");
            Stats.replace(context, history == null ? new JSONObject() : history);
            ReminderScheduler.rescheduleAll(context);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }
}
