package com.example.todo;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.List;

/** جدولة التذكيرات وإظهار الإشعارات. */
public final class ReminderScheduler {

    public static final String EXTRA_TASK_ID = "task_id";
    private static final String ACTION_REMIND = "com.example.todo.ACTION_REMIND";
    private static final String CHANNEL_ID = "task_reminders";

    private ReminderScheduler() {}

    private static int requestCode(long id) {
        return ((int) (id ^ (id >>> 32))) & 0x7fffffff;
    }

    private static PendingIntent alarmIntent(Context context, long id) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_REMIND);
        intent.putExtra(EXTRA_TASK_ID, id);
        return PendingIntent.getBroadcast(context, requestCode(id), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    public static void cancel(Context context, long id) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(alarmIntent(context, id));
    }

    /** يلغي التذكير القديم ثم يضبط تذكيراً جديداً إن كان الوقت في المستقبل والمهمة غير منجزة. */
    public static void schedule(Context context, Task task) {
        Context app = context.getApplicationContext();
        cancel(app, task.id);
        // المهمة المتكررة المنجزة تبقى مجدولة لموعدها القادم
        boolean skip = task.done && task.repeat == Task.REPEAT_NONE;
        if (skip || task.startTime <= System.currentTimeMillis()) return;

        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = alarmIntent(app, task.id);
        try {
            if (canScheduleExact(app)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.startTime, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.startTime, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.startTime, pi);
        }
    }

    public static void rescheduleAll(Context context) {
        List<Task> all = new TaskStore(context).load();
        for (Task t : all) schedule(context, t);
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notif_channel),
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(context.getString(R.string.notif_channel_desc));
        nm.createNotificationChannel(channel);
    }

    public static void showNotification(Context context, Task task) {
        ensureChannel(context);

        Intent detail = new Intent(context, TaskDetailActivity.class);
        detail.putExtra(TaskDetailActivity.EXTRA_TASK_ID, task.id);
        PendingIntent content = TaskStackBuilder.create(context)
                .addNextIntentWithParentStack(detail)
                .getPendingIntent(requestCode(task.id),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(context, CHANNEL_ID);
        } else {
            b = new Notification.Builder(context)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL);
        }
        b.setSmallIcon(R.drawable.ic_notification)
                .setColor(0xFF4F6BED)
                .setContentTitle(context.getString(R.string.notif_title))
                .setContentText(task.title)
                .setStyle(new Notification.BigTextStyle().bigText(task.title))
                .setContentIntent(content)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true);

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(requestCode(task.id), b.build());
    }
}
