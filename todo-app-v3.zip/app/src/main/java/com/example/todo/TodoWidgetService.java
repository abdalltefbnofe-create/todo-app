package com.example.todo;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import java.util.ArrayList;
import java.util.List;

/** يزوّد قائمة الويدجت بالمهام غير المنجزة مرتبة حسب الأولوية. */
public class TodoWidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    private static class Factory implements RemoteViewsFactory {

        private final Context context;
        private final List<Task> items = new ArrayList<>();

        Factory(Context context) {
            this.context = context;
        }

        @Override
        public void onCreate() {}

        @Override
        public void onDataSetChanged() {
            items.clear();
            for (Task t : new TaskStore(context).load()) {
                if (!t.done) items.add(t);
            }
            TaskStore.sortPending(items);
        }

        @Override
        public void onDestroy() {
            items.clear();
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {
            if (position < 0 || position >= items.size()) return null;
            Task t = items.get(position);

            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget_item);

            String prefix = t.priority == 2 ? "🔴 " : (t.priority == 1 ? "🟠 " : "");
            rv.setTextViewText(R.id.w_title, prefix + t.title);

            StringBuilder meta = new StringBuilder();
            if (t.startTime > 0) meta.append("⏰ ").append(Task.formatTime(t.startTime));
            String[] repeats = context.getResources().getStringArray(R.array.repeat_labels);
            if (t.repeat > 0 && t.repeat < repeats.length) {
                if (meta.length() > 0) meta.append("   ");
                meta.append(repeats[t.repeat]);
            }
            if (meta.length() > 0) {
                rv.setTextViewText(R.id.w_meta, meta.toString());
                rv.setViewVisibility(R.id.w_meta, View.VISIBLE);
            } else {
                rv.setViewVisibility(R.id.w_meta, View.GONE);
            }

            Intent fill = new Intent();
            fill.putExtra(TodoWidgetProvider.EXTRA_TASK_ID, t.id);
            rv.setOnClickFillInIntent(R.id.w_root, fill);
            return rv;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int position) {
            return position < items.size() ? items.get(position).id : position;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }
    }
}
