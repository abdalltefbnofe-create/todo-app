package com.example.todo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/** طبقة شفافة تعرض قصاصات ملوّنة تتطاير احتفالاً بالإنجاز. */
public class ConfettiView extends View {

    private static final int[] COLORS = {
            0xFFFF6B6B, 0xFFFFD93D, 0xFF6BCB77, 0xFF4D96FF, 0xFFB983FF, 0xFFFF9F45
    };

    private static class Piece {
        float x, y, vx, vy, size, rot, vr, life;
        int color;
        boolean circle;
    }

    private final ArrayList<Piece> pieces = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final float density;
    private long lastNanos;
    private boolean running;

    public ConfettiView(Context context) {
        this(context, null);
    }

    public ConfettiView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        setClickable(false);
        setFocusable(false);
    }

    /** ينثر قصاصات من النقطة (cx, cy) إلى الأعلى ثم تسقط بفعل الجاذبية. */
    public void burst(float cx, float cy, int count) {
        for (int i = 0; i < count; i++) {
            Piece p = new Piece();
            p.x = cx;
            p.y = cy;
            double angle = -Math.PI / 2 + (random.nextDouble() - 0.5) * Math.PI * 1.3;
            float speed = (350f + random.nextFloat() * 750f) * density;
            p.vx = (float) Math.cos(angle) * speed;
            p.vy = (float) Math.sin(angle) * speed;
            p.size = (6f + random.nextFloat() * 6f) * density;
            p.rot = random.nextFloat() * 360f;
            p.vr = (random.nextFloat() - 0.5f) * 720f;
            p.life = 1.6f + random.nextFloat() * 0.8f;
            p.color = COLORS[random.nextInt(COLORS.length)];
            p.circle = random.nextBoolean();
            pieces.add(p);
        }
        if (!running) {
            running = true;
            lastNanos = System.nanoTime();
            postOnAnimation(tick);
        }
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = System.nanoTime();
            float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.05f);
            lastNanos = now;

            Iterator<Piece> it = pieces.iterator();
            while (it.hasNext()) {
                Piece p = it.next();
                p.vy += 1700f * density * dt;
                p.vx *= (1f - 0.9f * dt);
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.rot += p.vr * dt;
                p.life -= dt;
                if (p.life <= 0 || p.y > getHeight() + 50 * density) it.remove();
            }
            invalidate();
            if (pieces.isEmpty()) {
                running = false;
            } else {
                postOnAnimation(this);
            }
        }
    };

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Piece p : pieces) {
            paint.setColor(p.color);
            paint.setAlpha((int) (255 * Math.min(1f, p.life / 0.5f)));
            canvas.save();
            canvas.rotate(p.rot, p.x, p.y);
            if (p.circle) {
                canvas.drawCircle(p.x, p.y, p.size / 2f, paint);
            } else {
                canvas.drawRect(p.x - p.size / 2f, p.y - p.size / 3f,
                        p.x + p.size / 2f, p.y + p.size / 3f, paint);
            }
            canvas.restore();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        running = false;
        pieces.clear();
        super.onDetachedFromWindow();
    }
}
