package com.example.todo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    public static final String EXTRA_FOCUS_INPUT = "focus_input";

    private static final int REQ_EXPORT = 1;
    private static final int REQ_IMPORT = 2;

    private TaskStore store;
    private final ArrayList<Task> shown = new ArrayList<>();
    private final ArrayList<TextView> chips = new ArrayList<>();
    private int filterCategory = -1; // -1 يعني كل التصنيفات
    private TaskAdapter adapter;
    private EditText input;
    private TextView progressText;
    private TextView motivationText;
    private ProgressBar progressBar;
    private ConfettiView confetti;

    // ---------- دورة حياة الشاشة ----------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        store = new TaskStore(this);

        input = findViewById(R.id.input_task);
        progressText = findViewById(R.id.progress_text);
        motivationText = findViewById(R.id.motivation_text);
        progressBar = findViewById(R.id.progress_bar);
        confetti = findViewById(R.id.confetti);

        TextView dateText = findViewById(R.id.date_text);
        dateText.setText(new SimpleDateFormat("EEEE، d MMMM", Locale.forLanguageTag("ar"))
                .format(new Date()));

        findViewById(R.id.btn_stats).setOnClickListener(
                v -> startActivity(new Intent(this, StatsActivity.class)));
        findViewById(R.id.btn_backup).setOnClickListener(v -> showBackupMenu());

        ListView listView = findViewById(R.id.list_tasks);
        listView.setEmptyView(findViewById(R.id.empty_view));
        adapter = new TaskAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < shown.size()) openDetail(shown.get(position));
        });

        findViewById(R.id.btn_add).setOnClickListener(v -> addTask());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                addTask();
                return true;
            }
            return false;
        });

        buildChips();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        // يعيد ضبط التذكيرات (مفيد بعد منح إذن المنبّهات الدقيقة)
        ReminderScheduler.rescheduleAll(this);
    }

    /** زر + في الويدجت يفتح التطبيق مع تجهيز خانة الكتابة. */
    private void handleIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra(EXTRA_FOCUS_INPUT, false)) {
            intent.removeExtra(EXTRA_FOCUS_INPUT);
            input.postDelayed(() -> {
                input.requestFocus();
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }, 300);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- شريط التصنيفات ----------
    private void buildChips() {
        LinearLayout container = findViewById(R.id.chip_container);
        container.removeAllViews();
        chips.clear();
        String[] names = getResources().getStringArray(R.array.categories);
        addChip(container, getString(R.string.filter_all), -1);
        for (int i = 0; i < names.length; i++) {
            addChip(container, names[i], i);
        }
        updateChips();
    }

    private void addChip(LinearLayout container, String label, final int category) {
        TextView chip = new TextView(this);
        chip.setText(label);
        chip.setTextSize(14);
        chip.setTag(category);
        chip.setPadding(dp(16), dp(8), dp(16), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(dp(8));
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> {
            filterCategory = category;
            updateChips();
            refresh();
        });
        container.addView(chip);
        chips.add(chip);
    }

    private void updateChips() {
        for (TextView chip : chips) {
            boolean selected = ((Integer) chip.getTag()) == filterCategory;
            chip.setBackgroundResource(selected ? R.drawable.chip_bg_selected : R.drawable.chip_bg);
            chip.setTextColor(selected ? 0xFFFFFFFF : getColor(R.color.text));
        }
    }

    // ---------- تحميل وعرض ----------
    private void refresh() {
        List<Task> all = store.load();

        ArrayList<Task> pending = new ArrayList<>();
        ArrayList<Task> finished = new ArrayList<>();
        int doneCount = 0;
        for (Task t : all) {
            if (t.done) doneCount++;
            if (filterCategory != -1 && t.category != filterCategory) continue;
            if (t.done) {
                finished.add(t);
            } else {
                pending.add(t);
            }
        }
        TaskStore.sortPending(pending);
        Collections.sort(finished, (a, b) -> Long.compare(b.completedAt, a.completedAt));

        shown.clear();
        shown.addAll(pending);
        shown.addAll(finished);

        adapter.notifyDataSetChanged();
        updateHeader(all.size(), doneCount);
    }

    private void updateHeader(int total, int done) {
        progressBar.setMax(Math.max(total, 1));
        progressBar.setProgress(done, true);
        progressText.setText(getString(R.string.progress_fmt, done, total));

        int msg;
        if (total == 0) {
            msg = R.string.motiv_none;
        } else if (done == total) {
            msg = R.string.motiv_all;
        } else if (done == 0) {
            msg = R.string.motiv_zero;
        } else if (done * 2 < total) {
            msg = R.string.motiv_low;
        } else {
            msg = R.string.motiv_high;
        }
        motivationText.setText(msg);
    }

    // ---------- العمليات ----------
    private void addTask() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, R.string.empty_warning, Toast.LENGTH_SHORT).show();
            return;
        }
        List<Task> all = store.load();
        Task t = new Task(System.currentTimeMillis(), text);
        if (filterCategory > 0) t.category = filterCategory; // المهمة تأخذ التصنيف المعروض حالياً
        all.add(0, t);
        store.save(all);
        input.setText("");
        refresh();
    }

    private void toggleTask(Task task, View checkView) {
        List<Task> all = store.load();
        Task cur = TaskStore.find(all, task.id);
        if (cur == null) return;

        store.applyDone(cur, !cur.done);
        store.save(all);
        ReminderScheduler.schedule(this, cur);

        if (cur.done) {
            boolean allDone = true;
            for (Task t : all) {
                if (!t.done) {
                    allDone = false;
                    break;
                }
            }
            Celebrate.haptic(checkView);
            Celebrate.bounce(checkView);
            Celebrate.burstFrom(confetti, checkView, 60);
            if (allDone) {
                Celebrate.bigBurst(confetti);
                Toast.makeText(this, R.string.all_done_toast, Toast.LENGTH_LONG).show();
            } else {
                Celebrate.cheer(this);
            }
        }
        refresh();
    }

    private void confirmDelete(final Task task) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirm_delete_title)
                .setMessage(R.string.confirm_delete_msg)
                .setPositiveButton(R.string.yes_delete, (d, w) -> {
                    List<Task> all = store.load();
                    Task cur = TaskStore.find(all, task.id);
                    if (cur != null) {
                        all.remove(cur);
                        ReminderScheduler.cancel(this, cur.id);
                        store.save(all);
                    }
                    refresh();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void openDetail(Task task) {
        Intent i = new Intent(this, TaskDetailActivity.class);
        i.putExtra(TaskDetailActivity.EXTRA_TASK_ID, task.id);
        startActivity(i);
    }

    private String buildMeta(Task t) {
        ArrayList<String> parts = new ArrayList<>();

        if (t.startTime > 0) {
            String time = "⏰ " + Task.formatTime(t.startTime);
            if (!t.done && t.startTime < System.currentTimeMillis()) {
                time += " • " + getString(R.string.overdue);
            }
            parts.add(time);
        }
        if (!t.subtasks.isEmpty()) {
            parts.add("☑ " + t.doneSubtasks() + "/" + t.subtasks.size());
        }
        String[] repeats = getResources().getStringArray(R.array.repeat_labels);
        if (t.repeat > 0 && t.repeat < repeats.length) {
            parts.add(repeats[t.repeat]);
        }
        String[] cats = getResources().getStringArray(R.array.categories);
        if (t.category > 0 && t.category < cats.length) {
            parts.add("🏷 " + cats[t.category]);
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append("    ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    // ---------- النسخ الاحتياطي ----------
    private void showBackupMenu() {
        String[] items = {getString(R.string.backup_save), getString(R.string.backup_restore)};
        new AlertDialog.Builder(this)
                .setTitle(R.string.backup_title)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        startExport();
                    } else {
                        startImport();
                    }
                })
                .show();
    }

    private void startExport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "mahami-backup-"
                + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".json");
        startActivityForResult(i, REQ_EXPORT);
    }

    private void startImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) {
            writeBackup(uri);
        } else if (requestCode == REQ_IMPORT) {
            confirmRestore(uri);
        }
    }

    private void writeBackup(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("no stream");
            out.write(store.exportJson().getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, R.string.backup_saved, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.backup_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void confirmRestore(final Uri uri) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.restore_confirm_title)
                .setMessage(R.string.restore_confirm_msg)
                .setPositiveButton(R.string.restore_yes, (d, w) -> restoreBackup(uri))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void restoreBackup(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("no stream");
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            while ((n = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, n);
            }
            String text = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
            if (store.importJson(text)) {
                Toast.makeText(this, R.string.restore_done, Toast.LENGTH_LONG).show();
                refresh();
            } else {
                Toast.makeText(this, R.string.restore_failed, Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, R.string.restore_failed, Toast.LENGTH_LONG).show();
        }
    }

    // ---------- المحوّل الذي يعرض القائمة ----------
    private class TaskAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int position) {
            return shown.get(position);
        }

        @Override
        public long getItemId(int position) {
            return shown.get(position).id;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(MainActivity.this)
                        .inflate(R.layout.item_task, parent, false);
            }

            final Task task = shown.get(position);
            ImageView check = convertView.findViewById(R.id.check);
            TextView priority = convertView.findViewById(R.id.task_priority);
            TextView title = convertView.findViewById(R.id.task_title);
            TextView meta = convertView.findViewById(R.id.task_meta);
            ImageButton delete = convertView.findViewById(R.id.btn_delete);

            title.setText(task.title);
            check.setImageResource(task.done ? R.drawable.ic_check_on : R.drawable.ic_check_off);

            String[] priorities = getResources().getStringArray(R.array.priority_labels);
            if (task.priority > 0 && task.priority < priorities.length) {
                priority.setVisibility(View.VISIBLE);
                priority.setText(priorities[task.priority]);
                priority.setTextColor(getColor(task.priority == 2 ? R.color.danger : R.color.warning));
            } else {
                priority.setVisibility(View.GONE);
            }

            if (task.done) {
                title.setPaintFlags(title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                convertView.setAlpha(0.55f);
            } else {
                title.setPaintFlags(title.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
                convertView.setAlpha(1f);
            }

            String m = buildMeta(task);
            if (m.isEmpty()) {
                meta.setVisibility(View.GONE);
            } else {
                meta.setVisibility(View.VISIBLE);
                meta.setText(m);
                boolean overdue = !task.done && task.startTime > 0
                        && task.startTime < System.currentTimeMillis();
                meta.setTextColor(getColor(overdue ? R.color.danger : R.color.text_secondary));
            }

            check.setOnClickListener(v -> toggleTask(task, v));
            delete.setOnClickListener(v -> confirmDelete(task));
            return convertView;
        }
    }
}
