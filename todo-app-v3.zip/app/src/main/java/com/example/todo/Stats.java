package com.example.todo;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.TreeSet;

/** سجل الإنجاز: عدد المهام المنجزة في كل يوم، ومنه تُحسب السلسلة والإحصائيات. */
public final class Stats {

    private static final String PREFS_NAME = "todo_prefs";
    private static final String KEY_HISTORY = "history";

    private Stats() {}

    private static String dayKey(Calendar cal) {
        return String.format(Locale.US, "%04d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
    }

    private static Calendar calOf(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        return c;
    }

    public static JSONObject load(Context context) {
        try {
            return new JSONObject(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .getString(KEY_HISTORY, "{}"));
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    public static void replace(Context context, JSONObject history) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_HISTORY, history.toString())
                .apply();
    }

    private static void adjust(Context context, long millis, int delta) {
        JSONObject h = load(context);
        String key = dayKey(calOf(millis));
        int n = Math.max(0, h.optInt(key, 0) + delta);
        try {
            if (n == 0) {
                h.remove(key);
            } else {
                h.put(key, n);
            }
        } catch (JSONException e) {
            return;
        }
        replace(context, h);
    }

    public static void record(Context context, long millis) {
        adjust(context, millis, 1);
    }

    public static void undo(Context context, long millis) {
        adjust(context, millis, -1);
    }

    private static int countOn(JSONObject h, Calendar cal) {
        return h.optInt(dayKey(cal), 0);
    }

    /** أعداد آخر n يوماً؛ العنصر الأخير هو اليوم. */
    public static int[] lastDays(Context context, int n) {
        JSONObject h = load(context);
        int[] out = new int[n];
        Calendar cal = Calendar.getInstance();
        for (int i = n - 1; i >= 0; i--) {
            out[i] = countOn(h, cal);
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        return out;
    }

    /** عدد الأيام المتتالية التي أنجزت فيها مهمة واحدة على الأقل (تنتهي اليوم أو أمس). */
    public static int streak(Context context) {
        JSONObject h = load(context);
        Calendar cal = Calendar.getInstance();
        if (countOn(h, cal) == 0) cal.add(Calendar.DAY_OF_YEAR, -1);
        int s = 0;
        while (countOn(h, cal) > 0) {
            s++;
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        return s;
    }

    public static int total(Context context) {
        JSONObject h = load(context);
        int sum = 0;
        Iterator<String> it = h.keys();
        while (it.hasNext()) {
            sum += h.optInt(it.next(), 0);
        }
        return sum;
    }

    public static int bestStreak(Context context) {
        JSONObject h = load(context);
        TreeSet<Long> days = new TreeSet<>();
        Iterator<String> it = h.keys();
        while (it.hasNext()) {
            String key = it.next();
            if (h.optInt(key, 0) <= 0) continue;
            String[] p = key.split("-");
            if (p.length != 3) continue;
            try {
                GregorianCalendar g = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
                g.clear();
                g.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]));
                days.add(g.getTimeInMillis() / 86400000L);
            } catch (NumberFormatException ignored) {
                // مفتاح غير صالح، نتجاهله
            }
        }
        int best = 0;
        int run = 0;
        long prev = Long.MIN_VALUE;
        for (long d : days) {
            run = (d == prev + 1) ? run + 1 : 1;
            best = Math.max(best, run);
            prev = d;
        }
        return best;
    }
}
